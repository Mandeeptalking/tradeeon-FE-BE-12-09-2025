"""Market data streaming service - single source of truth for candles and indicators."""

