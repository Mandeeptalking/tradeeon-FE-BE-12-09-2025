// Trend indicators
export { default as EMA } from '../ema';

// Future trend indicators can be added here:
// export { default as SMA } from './sma';
// export { default as WMA } from './wma';
// export { default as VWMA } from './vwma';

