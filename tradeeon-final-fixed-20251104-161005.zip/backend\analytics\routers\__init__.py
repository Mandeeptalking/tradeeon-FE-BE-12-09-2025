"""Router modules for analytics service."""

